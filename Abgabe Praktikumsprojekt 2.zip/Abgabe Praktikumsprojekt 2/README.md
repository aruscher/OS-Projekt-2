OS-Projekt-2
============

UsefulLinks:
http://pubs.opengroup.org/onlinepubs/009695399/
